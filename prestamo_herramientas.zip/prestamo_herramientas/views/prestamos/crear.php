<!-- Inclusión de estilos de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Título de la vista -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Registrar Préstamo</h4>

    <!-- Formulario para registrar un nuevo préstamo -->
    <form action="prestamos.php?accion=guardar" method="post" class="row g-3">
        <!-- Campo de código de préstamo (autogenerado y solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Código de Préstamo:</label>
            <input type="text" class="form-control" name="codigo_prestamo" value="<?= $codigo_generado ?>" readonly>
        </div>

        <!-- Campo visible con el código de usuario (extraído de la sesión) -->
        <div class="col-md-4">
            <label class="form-label">Usuario:</label>
            <input type="text" class="form-control" value="<?= $_SESSION['usuario']['codigo_usuario'] ?>" readonly>
            <!-- Campo oculto para enviar el valor al backend -->
            <input type="hidden" name="codigo_usuario" value="<?= $_SESSION['usuario']['codigo_usuario'] ?>">
        </div>

        <!-- Selección de herramienta disponible -->
        <div class="col-md-4">
            <label class="form-label">Herramienta:</label>
            <select name="codigo_herramienta" class="form-select" required>
                <option value="">Seleccione una herramienta</option>
                <?php foreach ($herramientas as $herr): ?>
                    <option value="<?= $herr['codigo_herramienta'] ?>">
                        <?= $herr['nombre'] ?> (<?= $herr['cantidad_disponible'] ?> disponibles)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Campo visible con la fecha actual (préstamo), más su campo oculto para enviar al backend -->
        <div class="col-md-6">
            <label class="form-label">Fecha de Préstamo:</label>
            <input type="date" class="form-control" name="fecha_prestamo" value="<?= date('Y-m-d') ?>" readonly>
        </div>

        <!-- Campo para ingresar la fecha estimada de devolución -->
        <div class="col-md-6">
            <label class="form-label">Fecha de Devolución Estimada:</label>
            <input type="date" name="fecha_devolucion" class="form-control" required>
        </div>

        <!-- Botones para enviar o cancelar -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Registrar</button>
            <a href="prestamos.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>