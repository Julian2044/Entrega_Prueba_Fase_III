<!-- Cargar Bootstrap para estilos y componentes -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Título de la vista -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Solicitar Préstamo</h4>

    <!-- Mostrar mensaje de alerta si existe una notificación en sesión -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?= $_SESSION['mensaje'];
            unset($_SESSION['mensaje']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>

    <!-- Formulario de solicitud de préstamo -->
    <form action="registrar_prestamo.php" method="post" class="row g-3">

        <!-- Campo: Código del préstamo (prellenado y solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Código del Préstamo</label>
            <input type="text" class="form-control" name="codigo_prestamo" value="<?= $codigo_generado ?>" readonly>
        </div>

        <!-- Campo: Código del usuario desde la sesión (readonly) -->
        <div class="col-md-4">
            <label class="form-label">Código del Usuario</label>
            <input type="text" class="form-control" name="codigo_usuario" value="<?= $_SESSION['usuario']['codigo_usuario'] ?>" readonly>
        </div>

        <!-- Campo: Selección de herramienta a solicitar -->
        <div class="col-md-4">
            <label class="form-label">Herramienta</label>
            <select class="form-select" name="codigo_herramienta" required>
                <option value="">Seleccione una herramienta</option>
                <!-- Listado de herramientas disponibles -->
                <?php foreach ($herramientas as $herramienta): ?>
                    <option value="<?= $herramienta['codigo_herramienta'] ?>">
                        <?= $herramienta['codigo_herramienta'] . ' - ' . $herramienta['nombre'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Campo: Fecha estimada de devolución (input obligatorio) -->
        <div class="col-md-6">
            <label class="form-label">Fecha de Devolución Estimada</label>
            <input type="date" name="fecha_devolucion" class="form-control" required>
        </div>

        <!-- Botones de acción: enviar solicitud o cancelar -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Solicitar</button>
            <a href="prestamos_usuario.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>

<!-- Scripts de Bootstrap para alertas, validaciones y componentes interactivos -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>