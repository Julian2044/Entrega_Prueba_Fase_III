<!-- Cargar estilos de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal del contenido -->
<div class="container mt-4">
    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Mis Préstamos</h4>

    <!-- Alerta para mostrar mensajes almacenados en la sesión (por ejemplo, confirmaciones o avisos) -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
            <?= $_SESSION['mensaje'];
            unset($_SESSION['mensaje']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
        </div>
    <?php endif; ?>

    <!-- Tabla responsiva para mostrar el historial de préstamos -->
    <div class="table-responsive">
        <table class="table table-striped align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>Código</th>
                    <th>Herramienta</th>
                    <th>Fecha Préstamo</th>
                    <th>Fecha Estimada Devolución</th>
                    <th>Fecha Real Devolución</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <!-- Iteración de todos los préstamos del usuario -->
                <?php foreach ($prestamos as $p): ?>
                    <tr>
                        <!-- Código del préstamo -->
                        <td><?= $p['codigo_prestamo'] ?></td>

                        <!-- Nombre de la herramienta (si existe) -->
                        <td><?= $p['nombre_herramienta'] ?? '---' ?></td>

                        <!-- Fecha en la que se realizó el préstamo -->
                        <td><?= $p['fecha_prestamo'] ?></td>

                        <!-- Fecha estimada para devolver la herramienta -->
                        <td><?= $p['fecha_devolucion'] ?></td>

                        <!-- Fecha real de devolución, o mensaje si está pendiente -->
                        <td>
                            <?= $p['fecha_devolucion_real'] ? $p['fecha_devolucion_real'] : '<span class="text-muted">Pendiente</span>' ?>
                        </td>

                        <!-- Estado visual: Devuelto o Pendiente con estilos -->
                        <td>
                            <?php if ($p['fecha_devolucion_real']): ?>
                                <span class="badge bg-success">Devuelto</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Pendiente</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Script de Bootstrap para el funcionamiento de alertas y otros componentes -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>