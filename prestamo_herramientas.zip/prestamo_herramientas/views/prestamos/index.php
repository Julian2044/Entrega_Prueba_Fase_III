<!-- Inclusión de estilos de Bootstrap desde CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Título principal de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Gestión de Préstamos</h4>

    <!-- Mostrar mensaje de éxito si existe -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['mensaje'];
            unset($_SESSION['mensaje']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Botón para registrar un nuevo préstamo -->
    <div class="mb-3 text-end">
        <a href="prestamos.php?accion=crear" class="btn btn-sm btn-primary">Registrar préstamo</a>
    </div>

    <!-- Tabla de préstamos existentes -->
    <div class="table-responsive">
        <table class="table table-striped align-middle text-center">
            <thead class="table-light">
                <tr>
                    <th>Código Préstamo</th>
                    <th>Código Usuario</th>
                    <th>Código Herramienta</th>
                    <th>Fecha Préstamo</th>
                    <th>Devolución Estimada</th>
                    <th>Devolución Real</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Recorrer y mostrar todos los préstamos -->
                <?php foreach ($prestamos as $p): ?>
                    <tr>
                        <td><?= $p['codigo_prestamo'] ?></td>
                        <td><?= $p['codigo_usuario'] ?></td>
                        <td><?= $p['codigo_herramienta'] ?></td>
                        <td><?= $p['fecha_prestamo'] ?></td>
                        <td><?= $p['fecha_devolucion'] ?></td>

                        <!-- Mostrar "Pendiente" si aún no se ha devuelto -->
                        <td><?= $p['fecha_devolucion_real'] ?? '<span class="text-muted">Pendiente</span>' ?></td>

                        <!-- Acciones disponibles según el estado del préstamo -->
                        <td>
                            <div class="d-flex justify-content-center gap-2">
                                <?php if (!$p['fecha_devolucion_real']): ?>
                                    <!-- Opción para marcar como devuelto -->
                                    <a href="prestamos.php?accion=devolver&codigo=<?= $p['codigo_prestamo'] ?>" class="btn btn-sm btn-outline-success">Devolver</a>

                                    <!-- Opción para editar la fecha de devolución -->
                                    <a href="prestamos.php?accion=editar&codigo=<?= $p['codigo_prestamo'] ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                                <?php else: ?>
                                    <!-- Si ya fue devuelto, solo mostrar texto -->
                                    <span class="text-muted">Devuelto</span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Inclusión de los scripts de Bootstrap para funcionalidades como el cierre de alertas -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>