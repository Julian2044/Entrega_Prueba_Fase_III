<!-- Inclusión de estilos de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Título de la vista -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Editar Préstamo</h4>

    <!-- Formulario para actualizar un préstamo existente -->
    <form action="prestamos.php?accion=actualizar&codigo=<?= $prestamo['codigo_prestamo'] ?>" method="post" class="row g-3">

        <!-- Campo de código del préstamo (solo lectura) -->
        <div class="col-md-3">
            <label class="form-label">Código de Préstamo:</label>
            <input type="text" class="form-control" value="<?= $prestamo['codigo_prestamo'] ?>" readonly>
        </div>

        <!-- Campo de código del usuario asociado (solo lectura) -->
        <div class="col-md-3">
            <label class="form-label">Código de Usuario:</label>
            <input type="text" class="form-control" value="<?= $prestamo['codigo_usuario'] ?>" readonly>
        </div>

        <!-- Nombre de la herramienta asignada al préstamo (solo lectura) -->
        <div class="col-md-6">
            <label class="form-label">Herramienta Asignada:</label>
            <input type="text" class="form-control" value="<?= $herramienta['nombre'] ?>" readonly>
        </div>

        <!-- Fecha en que se realizó el préstamo (solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Fecha de Préstamo:</label>
            <input type="text" class="form-control" value="<?= $prestamo['fecha_prestamo'] ?>" readonly>
        </div>

        <!-- Campo editable para actualizar la fecha estimada de devolución -->
        <div class="col-md-4">
            <label class="form-label">Fecha Devolución Estimada:</label>
            <input type="date" class="form-control" name="fecha_devolucion" value="<?= $prestamo['fecha_devolucion'] ?>" required>
        </div>

        <!-- Botones de acción -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Actualizar</button>
            <a href="prestamos.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>

<!-- Inclusión de scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>