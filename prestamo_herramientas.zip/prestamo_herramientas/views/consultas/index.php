<!-- Enlace al CDN de Bootstrap para estilos responsivos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal con márgenes -->
<div class="container mt-4">
    <!-- Título de la página de consultas -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Consulta de Préstamos por Usuario</h4>

    <!-- Formulario de selección de usuario para consultar sus préstamos -->
    <form method="POST" action="consultas.php" class="row g-3 mb-4">
        <!-- Campo desplegable para seleccionar el usuario -->
        <div class="col-md-10">
            <select name="codigo_usuario" class="form-select" required>
                <option value="">Seleccione un usuario...</option>
                <!-- Llenado dinámico del combo con los usuarios disponibles -->
                <?php foreach ($usuarios as $u): ?>
                    <option value="<?= $u['codigo_usuario'] ?>" <?= isset($_POST['codigo_usuario']) && $_POST['codigo_usuario'] == $u['codigo_usuario'] ? 'selected' : '' ?>>
                        <?= $u['nombre'] . ' ' . $u['apellido'] ?> (<?= $u['codigo_usuario'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Botón para enviar el formulario y realizar la consulta -->
        <div class="col-md-2 d-grid">
            <button type="submit" class="btn btn-primary">Consultar</button>
        </div>
    </form>

    <!-- Mostrar resultados solo si existen -->
    <?php if (!empty($resultados)): ?>
        <!-- Tabla para mostrar los resultados de préstamos encontrados -->
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Código Préstamo</th>
                        <th>Usuario</th>
                        <th>Herramienta</th>
                        <th>Descripción</th>
                        <th>Fecha Préstamo</th>
                        <th>Fecha Devolución</th>
                        <th>Fecha Devolución Real</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Iterar sobre cada resultado y mostrarlo en una fila -->
                    <?php foreach ($resultados as $r): ?>
                        <tr>
                            <td><?= $r['codigo_prestamo'] ?></td>
                            <td><?= $r['nombre'] . ' ' . $r['apellido'] ?></td>
                            <td><?= $r['herramienta'] ?></td>
                            <td><?= $r['descripcion'] ?></td>
                            <td><?= $r['fecha_prestamo'] ?></td>
                            <td><?= $r['fecha_devolucion'] ?></td>
                            <!-- Si no hay devolución real aún, se muestra "Pendiente" -->
                            <td><?= $r['fecha_devolucion_real'] ?? '<span class="text-muted">Pendiente</span>' ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Si no hay resultados y se hizo una búsqueda, mostrar mensaje -->
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="alert alert-warning">No se encontraron resultados para ese usuario.</div>
    <?php endif; ?>
</div>