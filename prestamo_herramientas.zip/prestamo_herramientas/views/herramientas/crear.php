<!-- Enlace al CSS de Bootstrap para estilos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal de la vista -->
<div class="container mt-4">

    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Registrar Nueva Herramienta</h4>

    <!-- Formulario para registrar una nueva herramienta -->
    <!-- Envía datos por POST a herramientas.php con la acción 'guardar' -->
    <form action="herramientas.php?accion=guardar" method="post" class="row g-3">

        <!-- Campo de código generado automáticamente, solo lectura -->
        <div class="col-md-4">
            <label class="form-label">Código:</label>
            <input type="text" class="form-control" name="codigo_herramienta" value="<?= $codigo_generado ?>" readonly>
        </div>

        <!-- Campo para ingresar el nombre de la herramienta -->
        <div class="col-md-4">
            <label class="form-label">Nombre:</label>
            <input type="text" class="form-control" name="nombre" required>
        </div>

        <!-- Campo para ingresar la cantidad disponible de la herramienta -->
        <div class="col-md-4">
            <label class="form-label">Cantidad Disponible:</label>
            <input type="number" class="form-control" name="cantidad_disponible" min="1" required>
        </div>

        <!-- Campo para ingresar una descripción de la herramienta -->
        <div class="col-md-12">
            <label class="form-label">Descripción:</label>
            <textarea class="form-control" name="descripcion" rows="3"></textarea>
        </div>

        <!-- Botones de acción: Guardar o Cancelar -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a href="herramientas.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>