<!-- Enlace a Bootstrap para estilos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">

    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Gestión de Herramientas</h4>

    <!-- Mensaje de éxito (por ejemplo, al crear o actualizar) -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['mensaje'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>

    <!-- Botón para registrar una nueva herramienta -->
    <div class="mb-3 text-end">
        <a href="herramientas.php?accion=crear" class="btn btn-sm btn-primary">Nueva herramienta</a>
    </div>

    <!-- Tabla de herramientas existentes -->
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead class="table-light">
                <tr class="text-center">
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Disponibles</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php foreach ($herramientas as $h): ?>
                    <tr>
                        <!-- Código de la herramienta -->
                        <td><?= $h['codigo_herramienta'] ?></td>
                        <!-- Nombre -->
                        <td><?= $h['nombre'] ?></td>
                        <!-- Descripción -->
                        <td><?= $h['descripcion'] ?></td>
                        <!-- Cantidad disponible -->
                        <td><?= $h['cantidad_disponible'] ?></td>
                        <!-- Acciones disponibles: Editar y Eliminar -->
                        <td>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="herramientas.php?accion=editar&codigo=<?= $h['codigo_herramienta'] ?>" class="btn btn-sm btn-outline-primary">Editar</a>
                                <a href="herramientas.php?accion=eliminar&codigo=<?= $h['codigo_herramienta'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar herramienta?')">Eliminar</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Script de Bootstrap para alertas y funcionalidad adicional -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>