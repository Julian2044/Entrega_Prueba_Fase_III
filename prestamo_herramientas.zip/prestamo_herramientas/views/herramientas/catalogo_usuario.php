<!-- Enlace al CSS de Bootstrap 5 para estilos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container mt-4">
    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Catálogo de Herramientas</h4>

    <!-- Contenedor que hace la tabla desplazable horizontalmente en pantallas pequeñas -->
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <!-- Encabezado de la tabla con estilos centrados -->
            <thead class="table-light text-center">
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Disponibles</th>
                </tr>
            </thead>

            <tbody>
                <!-- Bucle para mostrar cada herramienta disponible -->
                <?php foreach ($herramientas as $h): ?>
                    <tr class="text-center">
                        <td><?= $h['codigo_herramienta'] ?></td>
                        <td><?= $h['nombre'] ?></td>
                        <td><?= $h['descripcion'] ?></td>
                        <td>
                            <!-- Se muestra la cantidad disponible con estilo en negrita -->
                            <span class="d-inline-block fw-bold" style="min-width: 40px;">
                                <?= $h['cantidad_disponible'] ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Script JS de Bootstrap para funcionalidades como dropdowns, alerts, etc. -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>