<!-- Enlace a Bootstrap para estilos y diseño responsive -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal de la página -->
<div class="container mt-4">

    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Editar Herramienta</h4>

    <!-- Formulario para actualizar la información de una herramienta -->
    <!-- Envía los datos a herramientas.php con la acción 'actualizar' -->
    <form action="herramientas.php?accion=actualizar" method="post" class="row g-3">

        <!-- Campo para mostrar el código de la herramienta (no editable) -->
        <div class="col-md-4">
            <label class="form-label">Código:</label>
            <input type="text" class="form-control" name="codigo_herramienta" value="<?= $herramienta['codigo_herramienta'] ?>" readonly>
        </div>

        <!-- Campo editable para el nombre de la herramienta -->
        <div class="col-md-4">
            <label class="form-label">Nombre:</label>
            <input type="text" class="form-control" name="nombre" value="<?= $herramienta['nombre'] ?>" required>
        </div>

        <!-- Campo editable para la cantidad disponible -->
        <div class="col-md-4">
            <label class="form-label">Cantidad Disponible:</label>
            <input type="number" class="form-control" name="cantidad_disponible" value="<?= $herramienta['cantidad_disponible'] ?>" min="0" required>
        </div>

        <!-- Campo editable para la descripción de la herramienta -->
        <div class="col-md-12">
            <label class="form-label">Descripción:</label>
            <textarea class="form-control" name="descripcion" rows="3"><?= $herramienta['descripcion'] ?></textarea>
        </div>

        <!-- Botones para actualizar la herramienta o cancelar la acción -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-success">Actualizar</button>
            <a href="herramientas.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>