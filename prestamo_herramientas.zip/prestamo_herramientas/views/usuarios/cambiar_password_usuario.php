<!-- Carga la hoja de estilos de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Título de la sección -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Cambiar Contraseña</h4>

    <!-- Muestra un mensaje de éxito si existe -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-success">
            <?= $_SESSION['mensaje'] ?>
        </div>
        <?php unset($_SESSION['mensaje']); ?>

        <!-- Muestra un mensaje de error si existe -->
    <?php elseif (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <?= $_SESSION['error'] ?>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Formulario para cambiar la contraseña -->
    <form action="cambiar_password_usuario.php" method="post" class="row g-3">
        <!-- Código del usuario (solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Código:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($usuario['codigo_usuario']) ?>" readonly>
        </div>

        <!-- Nombre del usuario (solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Nombre:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($usuario['nombre']) ?>" readonly>
        </div>

        <!-- Apellido del usuario (solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Apellido:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($usuario['apellido']) ?>" readonly>
        </div>

        <!-- Email del usuario (solo lectura) -->
        <div class="col-md-6">
            <label class="form-label">Correo electrónico:</label>
            <input type="email" class="form-control" value="<?= htmlspecialchars($usuario['email']) ?>" readonly>
        </div>

        <!-- Rol del usuario (solo lectura) -->
        <div class="col-md-3">
            <label class="form-label">Rol:</label>
            <input type="text" class="form-control" value="<?= htmlspecialchars($usuario['rol']) ?>" readonly>
        </div>

        <!-- Campo para ingresar la nueva contraseña -->
        <div class="col-md-3">
            <label class="form-label">Nueva contraseña:</label>
            <input type="password" class="form-control" name="nueva_password" required>
        </div>

        <!-- Botón para enviar el formulario -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </div>
    </form>
</div>