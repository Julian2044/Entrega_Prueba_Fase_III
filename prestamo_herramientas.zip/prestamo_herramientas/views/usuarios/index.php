<!-- Carga de estilos de Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">

    <!-- Título principal -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Gestión de Usuarios</h4>

    <!-- Alerta de éxito si hay un mensaje en sesión -->
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['mensaje'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>

    <!-- Alerta de error si hay error en sesión -->
    <?php if (!empty($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Botón para crear nuevo usuario -->
    <div class="mb-3 text-end">
        <a href="usuarios.php?accion=crear" class="btn btn-sm btn-primary">Crear nuevo usuario</a>
    </div>

    <!-- Tabla de usuarios -->
    <div class="table-responsive">
        <table class="table table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!-- Iteración de cada usuario en la tabla -->
                <?php foreach ($usuarios as $usuario): ?>
                    <tr>
                        <td><?= $usuario['codigo_usuario'] ?></td>
                        <td><?= $usuario['nombre'] ?></td>
                        <td><?= $usuario['apellido'] ?></td>
                        <td><?= $usuario['email'] ?></td>
                        <td><?= $usuario['rol'] ?></td>
                        <td>
                            <!-- Badge dinámico según estado -->
                            <span class="badge bg-<?= $usuario['estado'] === 'activo' ? 'success' : 'secondary' ?>">
                                <?= ucfirst($usuario['estado']) ?>
                            </span>
                        </td>
                        <td>
                            <!-- Acciones disponibles para el usuario -->
                            <div class="d-flex gap-1 flex-wrap">
                                <!-- Botón para editar -->
                                <a href="usuarios.php?accion=editar&codigo=<?= $usuario['codigo_usuario'] ?>" class="btn btn-sm btn-outline-primary">Editar</a>

                                <!-- Botón para eliminar/inactivar o activar según el estado -->
                                <?php if ($usuario['estado'] === 'activo'): ?>
                                    <a href="usuarios.php?accion=eliminar&codigo=<?= $usuario['codigo_usuario'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Desea eliminar o inactivar este usuario?')">Eliminar</a>
                                <?php else: ?>
                                    <a href="usuarios.php?accion=activar&codigo=<?= $usuario['codigo_usuario'] ?>" class="btn btn-sm btn-outline-success" onclick="return confirm('¿Desea activar este usuario?')">Activar</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Carga de scripts de Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>