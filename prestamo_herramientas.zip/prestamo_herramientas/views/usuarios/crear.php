<!-- Carga la hoja de estilos de Bootstrap para estilos modernos -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal del formulario -->
<div class="container mt-4">
    <!-- Título con estilo -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Registrar Usuario</h4>

    <!-- Formulario para registrar un nuevo usuario -->
    <form action="usuarios.php?accion=guardar" method="post" class="row g-3">
        <!-- Campo: Código de usuario generado automáticamente (solo lectura) -->
        <div class="col-md-4">
            <label class="form-label">Código:</label>
            <input type="text" class="form-control" name="codigo_usuario" value="<?= $codigo_generado ?>" readonly>
        </div>

        <!-- Campo: Nombre del usuario -->
        <div class="col-md-4">
            <label class="form-label">Nombre:</label>
            <input type="text" class="form-control" name="nombre" required>
        </div>

        <!-- Campo: Apellido del usuario -->
        <div class="col-md-4">
            <label class="form-label">Apellido:</label>
            <input type="text" class="form-control" name="apellido" required>
        </div>

        <!-- Campo: Correo electrónico -->
        <div class="col-md-6">
            <label class="form-label">Correo electrónico:</label>
            <input type="email" class="form-control" name="email" required>
        </div>

        <!-- Campo: Rol del usuario (admin o usuario) -->
        <div class="col-md-3">
            <label class="form-label">Rol:</label>
            <select class="form-select" name="rol" required>
                <option value="admin">Admin</option>
                <option value="usuario">Usuario</option>
            </select>
        </div>

        <!-- Campo: Contraseña del nuevo usuario -->
        <div class="col-md-3">
            <label class="form-label">Contraseña:</label>
            <input type="password" class="form-control" name="password" required>
        </div>

        <!-- Botones para guardar o cancelar -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a href="usuarios.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>