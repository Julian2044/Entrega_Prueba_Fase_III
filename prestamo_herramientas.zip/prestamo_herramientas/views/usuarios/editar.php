<!-- Carga de estilos Bootstrap para una interfaz responsiva y moderna -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Contenedor principal -->
<div class="container mt-4">
    <!-- Encabezado de la página -->
    <h4 class="mb-4 border-bottom pb-2 text-dark">Editar Usuario</h4>

    <!-- Formulario para editar un usuario -->
    <form action="usuarios.php?accion=actualizar&codigo=<?= $usuario['codigo_usuario'] ?>" method="post" class="row g-3">

        <!-- Campo: Código del usuario (no editable) -->
        <div class="col-md-4">
            <label class="form-label">Código:</label>
            <input type="text" class="form-control" value="<?= $usuario['codigo_usuario'] ?>" readonly>
        </div>

        <!-- Campo: Nombre -->
        <div class="col-md-4">
            <label class="form-label">Nombre:</label>
            <input type="text" class="form-control" name="nombre" value="<?= $usuario['nombre'] ?>" required>
        </div>

        <!-- Campo: Apellido -->
        <div class="col-md-4">
            <label class="form-label">Apellido:</label>
            <input type="text" class="form-control" name="apellido" value="<?= $usuario['apellido'] ?>" required>
        </div>

        <!-- Campo: Correo electrónico -->
        <div class="col-md-6">
            <label class="form-label">Correo electrónico:</label>
            <input type="email" class="form-control" name="email" value="<?= $usuario['email'] ?>" required>
        </div>

        <!-- Campo: Rol del usuario (admin o usuario) -->
        <div class="col-md-3">
            <label class="form-label">Rol:</label>
            <select class="form-select" name="rol" required>
                <!-- Opción admin seleccionada si el rol actual es admin -->
                <option value="admin" <?= $usuario['rol'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                <!-- Opción usuario seleccionada si el rol actual es usuario -->
                <option value="usuario" <?= $usuario['rol'] === 'usuario' ? 'selected' : '' ?>>Usuario</option>
            </select>
        </div>

        <!-- Campo: Nueva contraseña (opcional) -->
        <div class="col-md-3">
            <label class="form-label">Nueva contraseña:</label>
            <input type="password" class="form-control" name="nueva_password" placeholder="Solo si desea cambiarla">
        </div>

        <!-- Botones de acción -->
        <div class="d-flex justify-content-end gap-2 mt-4">
            <button type="submit" class="btn btn-primary">Actualizar</button>
            <a href="usuarios.php" class="btn btn-outline-secondary">Cancelar</a>
        </div>
    </form>
</div>