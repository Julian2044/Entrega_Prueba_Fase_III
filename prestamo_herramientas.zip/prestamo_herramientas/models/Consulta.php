<?php
require_once '../config/conexion.php';

/**
 * Clase ConsultaModel
 * Encargada de realizar consultas específicas relacionadas con los préstamos por usuario.
 */
class ConsultaModel {

    /**
     * Obtiene todos los usuarios con sus códigos, nombres y apellidos.
     * Se utiliza para poblar listas desplegables u opciones de consulta.
     *
     * @return array Lista de usuarios ordenados por nombre.
     */
    public function obtenerUsuarios() {
        global $conexion;
        $sql = "SELECT codigo_usuario, nombre, apellido FROM usuarios ORDER BY nombre";
        $stmt = $conexion->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene los préstamos realizados por un usuario específico, incluyendo detalles de la herramienta.
     *
     * @param string $codigo_usuario Código único del usuario.
     * @return array Lista de préstamos con información del usuario, herramienta y fechas.
     */
    public function prestamosPorUsuario($codigo_usuario) {
        global $conexion;
        $sql = "SELECT 
                    p.codigo_prestamo,
                    u.codigo_usuario,
                    u.nombre,
                    u.apellido,
                    h.nombre AS herramienta,
                    h.descripcion,
                    p.fecha_prestamo,
                    p.fecha_devolucion,
                    p.fecha_devolucion_real
                FROM prestamos p
                JOIN usuarios u ON u.codigo_usuario = p.codigo_usuario
                JOIN herramientas h ON h.codigo_herramienta = p.codigo_herramienta
                WHERE u.codigo_usuario = :codigo_usuario
                ORDER BY p.fecha_prestamo DESC";

        $stmt = $conexion->prepare($sql);
        $stmt->execute(['codigo_usuario' => $codigo_usuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}