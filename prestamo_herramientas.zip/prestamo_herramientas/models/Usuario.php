<?php
// Incluye el archivo de conexión a la base de datos
require_once '../config/conexion.php';

/**
 * Clase Usuario
 * Contiene métodos estáticos para manejar operaciones CRUD y otras funciones
 * relacionadas con la tabla usuarios.
 */
class Usuario {

    /**
     * Obtiene todos los registros de usuarios.
     * @return array Lista de usuarios como arreglo asociativo.
     */
    public static function obtenerTodos() {
        global $conexion;
        $sql = "SELECT * FROM usuarios";
        return $conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene un usuario por su código único.
     * @param string $codigo Código del usuario.
     * @return array|null Datos del usuario o null si no se encuentra.
     */
    public static function obtenerPorCodigo($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE codigo_usuario = :codigo");
        $stmt->execute(['codigo' => $codigo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Crea un nuevo usuario en la base de datos.
     * @param string $codigo Código único generado.
     * @param string $nombre Nombre del usuario.
     * @param string $apellido Apellido del usuario.
     * @param string $email Correo electrónico.
     * @param string $rol Rol asignado (admin/usuario).
     * @param string $password Contraseña ya cifrada.
     */
    public static function crear($codigo, $nombre, $apellido, $email, $rol, $password) {
        global $conexion;
        $stmt = $conexion->prepare("
            INSERT INTO usuarios (codigo_usuario, nombre, apellido, email, rol, password, estado)
            VALUES (?, ?, ?, ?, ?, ?, 'activo')
        ");
        $stmt->execute([$codigo, $nombre, $apellido, $email, $rol, $password]);
    }

    /**
     * Actualiza los datos de un usuario, con o sin cambio de contraseña.
     * @param string $codigo Código del usuario.
     * @param string $nombre Nombre actualizado.
     * @param string $apellido Apellido actualizado.
     * @param string $email Email actualizado.
     * @param string $rol Rol actualizado.
     * @param string|null $nuevaPassword Nueva contraseña (opcional).
     */
    public static function actualizar($codigo, $nombre, $apellido, $email, $rol, $nuevaPassword = null) {
        global $conexion;

        if ($nuevaPassword) {
            $stmt = $conexion->prepare("
                UPDATE usuarios 
                SET nombre = ?, apellido = ?, email = ?, rol = ?, password = ?
                WHERE codigo_usuario = ?
            ");
            $stmt->execute([$nombre, $apellido, $email, $rol, $nuevaPassword, $codigo]);
        } else {
            $stmt = $conexion->prepare("
                UPDATE usuarios 
                SET nombre = ?, apellido = ?, email = ?, rol = ?
                WHERE codigo_usuario = ?
            ");
            $stmt->execute([$nombre, $apellido, $email, $rol, $codigo]);
        }
    }

    /**
     * Elimina un usuario por su código.
     * @param string $codigo Código del usuario.
     */
    public static function eliminar($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("DELETE FROM usuarios WHERE codigo_usuario = ?");
        $stmt->execute([$codigo]);
    }

    /**
     * Verifica si el usuario tiene préstamos pendientes.
     * @param string $codigo Código del usuario.
     * @return bool Verdadero si hay préstamos pendientes, falso si no.
     */
    public static function tienePrestamosPendientes($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("
            SELECT COUNT(*) FROM prestamos 
            WHERE codigo_usuario = ? AND fecha_devolucion_real IS NULL
        ");
        $stmt->execute([$codigo]);
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Cambia el estado de un usuario (activo/inactivo).
     * @param string $codigo Código del usuario.
     * @param string $estado Nuevo estado ('activo' o 'inactivo').
     */
    public static function cambiarEstado($codigo, $estado) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE usuarios SET estado = ? WHERE codigo_usuario = ?");
        $stmt->execute([$estado, $codigo]);
    }

    /**
     * Genera el siguiente código de usuario automático (ej: USR001).
     * @return string Código nuevo generado.
     */
    public static function generarSiguienteCodigo() {
        global $conexion;
        $sql = "SELECT codigo_usuario FROM usuarios ORDER BY codigo_usuario DESC LIMIT 1";
        $stmt = $conexion->query($sql);
        $ultimo = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($ultimo) {
            $numero = intval(substr($ultimo['codigo_usuario'], 3)) + 1;
        } else {
            $numero = 1;
        }

        return 'USR' . str_pad($numero, 3, '0', STR_PAD_LEFT);
    }
}