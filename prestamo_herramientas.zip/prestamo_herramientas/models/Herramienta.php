<?php
require_once __DIR__ . '/../config/conexion.php';

/**
 * Clase Herramienta
 * Maneja las operaciones CRUD y gestión de disponibilidad de herramientas.
 */
class Herramienta {

    /**
     * Obtiene todas las herramientas registradas.
     * @return array Lista de herramientas.
     */
    public static function obtenerTodos() {
        global $conexion;
        return $conexion->query("SELECT * FROM herramientas")->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene una herramienta específica por su código.
     * @param string $codigo Código de la herramienta.
     * @return array|null Datos de la herramienta o null si no existe.
     */
    public static function obtenerPorCodigo($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("SELECT * FROM herramientas WHERE codigo_herramienta = ?");
        $stmt->execute([$codigo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Crea una nueva herramienta.
     * @param string $codigo Código único.
     * @param string $nombre Nombre de la herramienta.
     * @param string $descripcion Descripción de uso.
     * @param int $cantidad Cantidad disponible.
     */
    public static function crear($codigo, $nombre, $descripcion, $cantidad) {
        global $conexion;
        $stmt = $conexion->prepare("INSERT INTO herramientas (codigo_herramienta, nombre, descripcion, cantidad_disponible) VALUES (?, ?, ?, ?)");
        $stmt->execute([$codigo, $nombre, $descripcion, $cantidad]);
    }

    /**
     * Actualiza los datos de una herramienta existente.
     * @param string $codigo Código de la herramienta.
     * @param string $nombre Nombre actualizado.
     * @param string $descripcion Descripción actualizada.
     * @param int $cantidad Nueva cantidad disponible.
     */
    public static function actualizar($codigo, $nombre, $descripcion, $cantidad) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE herramientas SET nombre = ?, descripcion = ?, cantidad_disponible = ? WHERE codigo_herramienta = ?");
        $stmt->execute([$nombre, $descripcion, $cantidad, $codigo]);
    }

    /**
     * Elimina una herramienta del sistema.
     * @param string $codigo Código de la herramienta.
     */
    public static function eliminar($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("DELETE FROM herramientas WHERE codigo_herramienta = ?");
        $stmt->execute([$codigo]);
    }

    /**
     * Verifica si una herramienta tiene unidades disponibles.
     * @param string $codigo Código de la herramienta.
     * @return bool True si hay unidades disponibles, false en caso contrario.
     */
    public static function estaDisponible($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("SELECT cantidad_disponible FROM herramientas WHERE codigo_herramienta = ?");
        $stmt->execute([$codigo]);
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Disminuye la cantidad disponible de una herramienta en 1.
     * @param string $codigo Código de la herramienta.
     */
    public static function reducirCantidad($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE herramientas SET cantidad_disponible = cantidad_disponible - 1 WHERE codigo_herramienta = ? AND cantidad_disponible > 0");
        $stmt->execute([$codigo]);
    }

    /**
     * Aumenta la cantidad disponible de una herramienta en 1.
     * @param string $codigo Código de la herramienta.
     */
    public static function aumentarCantidad($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE herramientas SET cantidad_disponible = cantidad_disponible + 1 WHERE codigo_herramienta = ?");
        $stmt->execute([$codigo]);
    }

    /**
     * Genera un nuevo código para una herramienta (formato: HERR001, HERR002...).
     * @return string Código generado.
     */
    public static function generarCodigo() {
        global $conexion;
        $stmt = $conexion->query("SELECT codigo_herramienta FROM herramientas ORDER BY codigo_herramienta DESC LIMIT 1");
        $ultimo = $stmt->fetchColumn();
        $num = $ultimo ? (int)substr($ultimo, 4) + 1 : 1;
        return 'HERR' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    /**
     * Devuelve solo las herramientas que tienen disponibilidad.
     * @return array Lista de herramientas disponibles.
     */
    public static function obtenerTodasDisponibles() {
        global $conexion;
        $stmt = $conexion->query("SELECT * FROM herramientas WHERE cantidad_disponible > 0");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}