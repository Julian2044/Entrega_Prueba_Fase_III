<?php
require_once '../config/conexion.php';

/**
 * Clase Prestamo
 * Maneja todas las operaciones relacionadas con los préstamos de herramientas.
 */
class Prestamo {

    /**
     * Obtiene todos los préstamos con la información del usuario y herramienta.
     * @return array Lista de préstamos con detalles del usuario y herramienta.
     */
    public static function obtenerTodos() {
        global $conexion;
        $sql = "SELECT p.*, u.codigo_usuario, u.nombre AS nombre_usuario, h.codigo_herramienta, h.nombre AS nombre_herramienta
                FROM prestamos p
                INNER JOIN usuarios u ON p.codigo_usuario = u.codigo_usuario
                INNER JOIN herramientas h ON p.codigo_herramienta = h.codigo_herramienta
                ORDER BY p.fecha_prestamo DESC";
        return $conexion->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene un préstamo por su código.
     * @param string $codigo Código del préstamo.
     * @return array|null Datos del préstamo o null si no existe.
     */
    public static function obtenerPorCodigo($codigo) {
        global $conexion;
        $stmt = $conexion->prepare("SELECT * FROM prestamos WHERE codigo_prestamo = ?");
        $stmt->execute([$codigo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Crea un nuevo préstamo.
     * @param string $codigo Código del préstamo.
     * @param string $codigo_usuario Código del usuario.
     * @param string $codigo_herramienta Código de la herramienta.
     * @param string $fecha_prestamo Fecha del préstamo.
     * @param string $fecha_devolucion Fecha estimada de devolución.
     */
    public static function crear($codigo, $codigo_usuario, $codigo_herramienta, $fecha_prestamo, $fecha_devolucion) {
        global $conexion;
        $stmt = $conexion->prepare("INSERT INTO prestamos 
            (codigo_prestamo, codigo_usuario, codigo_herramienta, fecha_prestamo, fecha_devolucion) 
            VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$codigo, $codigo_usuario, $codigo_herramienta, $fecha_prestamo, $fecha_devolucion]);
    }

    /**
     * Actualiza la fecha de devolución de un préstamo.
     * @param string $codigo Código del préstamo.
     * @param string $fecha_devolucion Nueva fecha de devolución.
     */
    public static function actualizar($codigo, $fecha_devolucion) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE prestamos SET fecha_devolucion = ? WHERE codigo_prestamo = ?");
        $stmt->execute([$fecha_devolucion, $codigo]);
    }

    /**
     * Registra la devolución real de una herramienta prestada.
     * @param string $codigo Código del préstamo.
     * @param string $fecha_real Fecha en que realmente se devolvió la herramienta.
     */
    public static function devolver($codigo, $fecha_real) {
        global $conexion;
        $stmt = $conexion->prepare("UPDATE prestamos SET fecha_devolucion_real = ? WHERE codigo_prestamo = ?");
        $stmt->execute([$fecha_real, $codigo]);
    }

    /**
     * Genera el siguiente código automático para un préstamo.
     * @return string Código generado con formato 'PRE###'.
     */
    public static function generarCodigo() {
        global $conexion;
        $sql = "SELECT codigo_prestamo FROM prestamos ORDER BY codigo_prestamo DESC LIMIT 1";
        $ultimo = $conexion->query($sql)->fetchColumn();
        $num = $ultimo ? (int)substr($ultimo, 3) + 1 : 1;
        return 'PRE' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    /**
     * Obtiene todos los préstamos asociados a un usuario.
     * @param string $codigo_usuario Código del usuario.
     * @return array Lista de préstamos del usuario.
     */
    public static function obtenerPorUsuario($codigo_usuario) {
        global $conexion;
        $sql = "SELECT p.*, h.nombre AS nombre_herramienta
                FROM prestamos p
                INNER JOIN herramientas h ON p.codigo_herramienta = h.codigo_herramienta
                WHERE p.codigo_usuario = ?
                ORDER BY p.fecha_prestamo DESC";
        $stmt = $conexion->prepare($sql);
        $stmt->execute([$codigo_usuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}