<?php
// Parámetros de conexión a la base de datos
$host = 'localhost'; // Dirección del servidor de base de datos (localhost si es local)
$db = 'prestamo_herramientas'; // Nombre de la base de datos
$user = 'root'; // Usuario de la base de datos (por defecto en XAMPP es 'root')
$pass = ''; // Contraseña (en XAMPP normalmente está vacía)

// Bloque try-catch para capturar errores de conexión
try {
    // Se crea una nueva instancia de conexión PDO con los parámetros definidos
    $conexion = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);

    // Configura el modo de error para lanzar excepciones si ocurre algún problema
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Si deseas ver si la conexión fue exitosa puedes descomentar la siguiente línea:
    // echo "Conexión exitosa";
} catch (PDOException $e) {
    // En caso de error, se detiene la ejecución y muestra el mensaje
    die("Error de conexión: " . $e->getMessage());
}
