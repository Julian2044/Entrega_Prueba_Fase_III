<?php
// Incluye los modelos necesarios para préstamos y herramientas
require_once __DIR__ . '/../models/Prestamo.php';
require_once __DIR__ . '/../models/Herramienta.php';

/**
 * Controlador encargado de gestionar los préstamos desde el panel del usuario.
 */
class PrestamoUsuarioController {

    /**
     * Muestra los préstamos asociados al usuario actualmente logueado.
     */
    public function index() {
        $codigo_usuario = $_SESSION['usuario']['codigo_usuario']; // Obtiene el código del usuario desde la sesión
        $prestamos = Prestamo::obtenerPorUsuario($codigo_usuario); // Consulta préstamos del usuario
        include __DIR__ . '/../views/prestamos/usuario_index.php'; // Carga la vista correspondiente
    }

    /**
     * Muestra el formulario para registrar un nuevo préstamo.
     */
    public function crear() {
        $codigo_generado = Prestamo::generarCodigo(); // Genera automáticamente un código de préstamo
        $herramientas = Herramienta::obtenerTodasDisponibles(); // Obtiene herramientas disponibles
        include __DIR__ . '/../views/prestamos/usuario_crear.php'; // Carga el formulario
    }

    /**
     * Procesa y guarda el nuevo préstamo solicitado por el usuario.
     */
    public function guardar() {
        // Captura los datos del formulario y sesión
        $codigo = $_POST['codigo_prestamo'];
        $codigo_usuario = $_SESSION['usuario']['codigo_usuario'];
        $codigo_herramienta = $_POST['codigo_herramienta'];
        $fecha_prestamo = date('Y-m-d'); // Fecha actual
        $fecha_devolucion = $_POST['fecha_devolucion'];

        // Validación de campos obligatorios
        if (!$codigo_herramienta || !$fecha_devolucion) {
            $_SESSION['mensaje'] = " Todos los campos son obligatorios.";
            header("Location: registrar_prestamo.php");
            exit();
        }

        // Verifica si la herramienta está disponible
        if (!Herramienta::estaDisponible($codigo_herramienta)) {
            $_SESSION['mensaje'] = " La herramienta no está disponible.";
            header("Location: registrar_prestamo.php");
            exit();
        }

        // Registra el préstamo y reduce la cantidad disponible de la herramienta
        Prestamo::crear($codigo, $codigo_usuario, $codigo_herramienta, $fecha_prestamo, $fecha_devolucion);
        Herramienta::reducirCantidad($codigo_herramienta);

        $_SESSION['mensaje'] = " Préstamo registrado correctamente.";
        header("Location: prestamos_usuario.php");
        exit();
    }
}