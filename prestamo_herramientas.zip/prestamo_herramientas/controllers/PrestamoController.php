<?php
// Importación de modelos necesarios
require_once '../models/Prestamo.php';
require_once '../models/Usuario.php';
require_once '../models/Herramienta.php';

/**
 * Controlador principal para la gestión de préstamos desde el panel de administrador.
 */
class PrestamoController
{

    /**
     * Muestra todos los préstamos registrados.
     */
    public function index()
    {
        $prestamos = Prestamo::obtenerTodos(); // Obtiene todos los préstamos
        include '../views/prestamos/index.php'; // Carga la vista principal de préstamos
    }

    /**
     * Muestra el formulario para crear un nuevo préstamo.
     */
    public function crear()
    {
        $codigo_generado = Prestamo::generarCodigo(); // Genera un nuevo código para el préstamo
        $herramientas = Herramienta::obtenerTodos(); // Lista todas las herramientas disponibles
        include '../views/prestamos/crear.php'; // Muestra el formulario de creación
    }

    /**
     * Guarda un nuevo préstamo después de validar los datos.
     */
    public function guardar()
    {
        // Recoge los datos enviados por el formulario
        $codigo = $_POST['codigo_prestamo'];
        $codigo_usuario = $_POST['codigo_usuario'];
        $codigo_herramienta = $_POST['codigo_herramienta'];
        $fecha_prestamo = $_POST['fecha_prestamo'];
        $fecha_devolucion = $_POST['fecha_devolucion'];

        // Validación básica de campos
        if (!$codigo_usuario || !$codigo_herramienta || !$fecha_devolucion) {
            $_SESSION['mensaje'] = " Todos los campos son obligatorios.";
            header("Location: prestamos.php?accion=crear");
            exit();
        }

        // Verifica disponibilidad de la herramienta
        if (!Herramienta::estaDisponible($codigo_herramienta)) {
            $_SESSION['mensaje'] = " La herramienta seleccionada no tiene disponibilidad.";
            header("Location: prestamos.php?accion=crear");
            exit();
        }

        // Crea el préstamo y actualiza el inventario
        Prestamo::crear($codigo, $codigo_usuario, $codigo_herramienta, $fecha_prestamo, $fecha_devolucion);
        Herramienta::reducirCantidad($codigo_herramienta);

        $_SESSION['mensaje'] = " Préstamo registrado exitosamente.";
        header("Location: prestamos.php");
        exit();
    }

    /**
     * Marca un préstamo como devuelto y actualiza la cantidad disponible de la herramienta.
     */
    public function devolver($codigo)
    {
        $fecha_real = date('Y-m-d'); // Fecha actual
        $prestamo = Prestamo::obtenerPorCodigo($codigo); // Obtiene el préstamo
        Prestamo::devolver($codigo, $fecha_real); // Marca la devolución en la base de datos
        Herramienta::aumentarCantidad($prestamo['codigo_herramienta']); // Aumenta inventario

        $_SESSION['mensaje'] = "✅ Préstamo marcado como devuelto.";
        header("Location: prestamos.php");
        exit();
    }

    /**
     * Muestra el formulario para editar un préstamo específico.
     */
    public function editar($codigo)
    {
        $prestamo = Prestamo::obtenerPorCodigo($codigo); // Datos del préstamo
        $herramienta = Herramienta::obtenerPorCodigo($prestamo['codigo_herramienta']); // Herramienta asociada
        include '../views/prestamos/editar.php'; // Carga la vista de edición
    }

    /**
     * Actualiza la fecha estimada de devolución del préstamo.
     */
    public function actualizar($codigo)
    {
        $fecha_devolucion = $_POST['fecha_devolucion']; // Nueva fecha

        if (!$fecha_devolucion) {
            $_SESSION['mensaje'] = " La fecha estimada de devolución es obligatoria.";
            header("Location: prestamos.php?accion=editar&codigo=$codigo");
            exit();
        }

        Prestamo::actualizar($codigo, $fecha_devolucion); // Actualiza la fecha
        $_SESSION['mensaje'] = " Préstamo actualizado correctamente.";
        header("Location: prestamos.php");
        exit();
    }
}
