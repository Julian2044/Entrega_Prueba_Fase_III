<?php
// Se incluye el modelo ConsultaModel
require_once __DIR__ . '/../models/Consulta.php';

/**
 * Controlador responsable de la lógica de consulta de préstamos por usuario.
 * Permite al administrador ver el historial de préstamos de un usuario específico.
 */
class ConsultaController {
    private $modelo;

    /**
     * Constructor del controlador. Inicializa una instancia del modelo ConsultaModel.
     */
    public function __construct() {
        $this->modelo = new ConsultaModel();
    }

    /**
     * Muestra el formulario de búsqueda y los resultados de préstamos por usuario.
     * Si se recibe una solicitud POST con un código de usuario, se ejecuta la consulta.
     */
    public function index() {
        // Obtiene todos los usuarios para mostrarlos en un select
        $usuarios = $this->modelo->obtenerUsuarios();

        // Arreglo donde se almacenarán los resultados de préstamos
        $resultados = [];

        // Si se envía el formulario (POST) y viene un código de usuario válido
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['codigo_usuario'])) {
            $codigo_usuario = $_POST['codigo_usuario'];

            // Consulta los préstamos realizados por el usuario seleccionado
            $resultados = $this->modelo->prestamosPorUsuario($codigo_usuario);
        }

        // Carga la vista con el formulario y los resultados (si los hay)
        require_once __DIR__ . '/../views/consultas/index.php';
    }
}