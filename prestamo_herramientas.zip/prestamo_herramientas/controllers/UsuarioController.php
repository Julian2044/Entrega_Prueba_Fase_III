<?php
require_once '../models/Usuario.php';

/**
 * Controlador para gestionar las operaciones relacionadas con los usuarios.
 */
class UsuarioController {

    /**
     * Muestra todos los usuarios en la vista principal.
     */
    public function index() {
        $usuarios = Usuario::obtenerTodos();
        include '../views/usuarios/index.php';
    }

    /**
     * Carga el formulario para crear un nuevo usuario.
     */
    public function crear() {
        try {
            // Genera el siguiente código de usuario automáticamente
            $codigo_generado = Usuario::generarSiguienteCodigo();
            include '../views/usuarios/crear.php';
        } catch (Exception $e) {
            // En caso de error, muestra un mensaje y redirige a la lista de usuarios
            $_SESSION['error'] = "Error al preparar formulario de creación: " . $e->getMessage();
            header("Location: ../public/usuarios.php");
        }
    }

    /**
     * Procesa y guarda los datos de un nuevo usuario enviados por formulario.
     */
    public function guardar() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            try {
                // Captura y sanitiza los datos del formulario
                $codigo   = $_POST['codigo_usuario'];
                $nombre   = $_POST['nombre'];
                $apellido = $_POST['apellido'];
                $email    = $_POST['email'];
                $rol      = $_POST['rol'];
                $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encripta la contraseña

                // Crea el usuario con los datos recibidos
                Usuario::crear($codigo, $nombre, $apellido, $email, $rol, $password);
                $_SESSION['mensaje'] = " Usuario creado correctamente.";
            } catch (Exception $e) {
                $_SESSION['error'] = " Error al crear usuario: " . $e->getMessage();
            }
            header("Location: ../public/usuarios.php");
        }
    }

    /**
     * Carga los datos de un usuario específico para editar.
     *
     * @param string $codigo Código único del usuario.
     */
    public function editar($codigo) {
        try {
            $usuario = Usuario::obtenerPorCodigo($codigo);
            include '../views/usuarios/editar.php';
        } catch (Exception $e) {
            $_SESSION['error'] = " Error al cargar usuario: " . $e->getMessage();
            header("Location: ../public/usuarios.php");
        }
    }

    /**
     * Actualiza los datos de un usuario específico.
     *
     * @param string $codigo Código único del usuario.
     */
    public function actualizar($codigo) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            try {
                // Recoge los datos del formulario
                $nombre   = $_POST['nombre'];
                $apellido = $_POST['apellido'];
                $email    = $_POST['email'];
                $rol      = $_POST['rol'];
                $nuevaPassword = !empty($_POST['nueva_password']) 
                    ? password_hash($_POST['nueva_password'], PASSWORD_DEFAULT) 
                    : null;

                // Actualiza el usuario con o sin contraseña nueva
                Usuario::actualizar($codigo, $nombre, $apellido, $email, $rol, $nuevaPassword);
                $_SESSION['mensaje'] = " Usuario actualizado correctamente.";
            } catch (Exception $e) {
                $_SESSION['error'] = " Error al actualizar usuario: " . $e->getMessage();
            }
            header("Location: ../public/usuarios.php");
        }
    }

    /**
     * Elimina un usuario si no tiene préstamos pendientes,
     * o lo marca como inactivo si los tiene.
     *
     * @param string $codigo Código único del usuario.
     */
    public function eliminar($codigo) {
        try {
            if (Usuario::tienePrestamosPendientes($codigo)) {
                Usuario::cambiarEstado($codigo, 'inactivo');
                $_SESSION['mensaje'] = " El usuario tiene préstamos pendientes. Se ha marcado como INACTIVO.";
            } else {
                Usuario::eliminar($codigo);
                $_SESSION['mensaje'] = " Usuario eliminado correctamente.";
            }
        } catch (Exception $e) {
            $_SESSION['error'] = " Error al eliminar usuario: " . $e->getMessage();
        }

        header("Location: ../public/usuarios.php");
    }

    /**
     * Reactiva un usuario marcándolo como 'activo'.
     *
     * @param string $codigo Código único del usuario.
     */
    public function activar($codigo) {
        try {
            Usuario::cambiarEstado($codigo, 'activo');
            $_SESSION['mensaje'] = " Usuario activado correctamente.";
        } catch (Exception $e) {
            $_SESSION['error'] = " Error al activar usuario: " . $e->getMessage();
        }

        header("Location: ../public/usuarios.php");
    }
}