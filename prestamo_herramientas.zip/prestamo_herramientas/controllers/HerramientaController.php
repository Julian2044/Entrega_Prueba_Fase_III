<?php
// Importa el modelo de herramienta
require_once __DIR__ . '/../models/Herramienta.php';

/**
 * Controlador para la gestión de herramientas.
 * Permite listar, crear, editar, actualizar y eliminar herramientas.
 */
class HerramientaController {

    /**
     * Muestra la lista de todas las herramientas disponibles.
     */
    public function index() {
        $herramientas = Herramienta::obtenerTodos(); // Consulta todas las herramientas de la base de datos
        include __DIR__ . '/../views/herramientas/index.php'; // Carga la vista de listado
    }

    /**
     * Muestra el formulario para crear una nueva herramienta.
     */
    public function crear() {
        $codigo_generado = Herramienta::generarCodigo(); // Genera automáticamente el nuevo código
        include __DIR__ . '/../views/herramientas/crear.php'; // Carga la vista de creación
    }

    /**
     * Guarda una nueva herramienta en la base de datos.
     */
    public function guardar() {
        // Obtiene los datos enviados por el formulario
        $codigo = $_POST['codigo_herramienta'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $cantidad = $_POST['cantidad_disponible'];

        // Validación de campos requeridos
        if (!$nombre || !$cantidad) {
            $_SESSION['mensaje'] = " Todos los campos obligatorios deben llenarse.";
            header("Location: herramientas.php?accion=crear");
            exit();
        }

        // Registra la herramienta en la base de datos
        Herramienta::crear($codigo, $nombre, $descripcion, $cantidad);
        $_SESSION['mensaje'] = " Herramienta registrada exitosamente.";
        header("Location: herramientas.php");
        exit();
    }

    /**
     * Muestra el formulario para editar una herramienta específica.
     * @param string $codigo Código de la herramienta a editar
     */
    public function editar($codigo) {
        $herramienta = Herramienta::obtenerPorCodigo($codigo); // Busca los datos de la herramienta
        include __DIR__ . '/../views/herramientas/editar.php'; // Carga la vista de edición
    }

    /**
     * Actualiza los datos de una herramienta existente.
     */
    public function actualizar() {
        // Datos enviados por el formulario de edición
        $codigo = $_POST['codigo_herramienta'];
        $nombre = $_POST['nombre'];
        $descripcion = $_POST['descripcion'];
        $cantidad = $_POST['cantidad_disponible'];

        // Actualiza la información en la base de datos
        Herramienta::actualizar($codigo, $nombre, $descripcion, $cantidad);
        $_SESSION['mensaje'] = " Herramienta actualizada.";
        header("Location: herramientas.php");
        exit();
    }

    /**
     * Elimina una herramienta de la base de datos.
     * @param string $codigo Código de la herramienta a eliminar
     */
    public function eliminar($codigo) {
        Herramienta::eliminar($codigo); // Elimina la herramienta
        $_SESSION['mensaje'] = " Herramienta eliminada.";
        header("Location: herramientas.php");
        exit();
    }
}