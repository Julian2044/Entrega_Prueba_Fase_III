<?php
// Inicia la sesión para poder acceder a las variables de sesión existentes
session_start();

// Destruye toda la información registrada en la sesión actual
session_destroy();

// Redirige al usuario de vuelta a la página de inicio de sesión
header("Location: login.php");

// Finaliza el script para evitar que se ejecute cualquier otro código
exit();