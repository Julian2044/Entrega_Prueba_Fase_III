<?php
// Inicia la sesión para gestionar variables como mensajes de éxito o error
session_start();

// Se incluye el controlador de Herramienta para gestionar la lógica
require_once '../controllers/HerramientaController.php';

// Se instancia el controlador de herramientas
$controlador = new HerramientaController();

// Se obtiene la acción desde la URL, si no hay acción, se usa 'index' por defecto
$accion = $_GET['accion'] ?? 'index';

// Se evalúa qué acción ejecutar dependiendo del parámetro 'accion' recibido
switch ($accion) {
    case 'crear':
        // Muestra el formulario para registrar una nueva herramienta
        $controlador->crear();
        break;

    case 'guardar':
        // Procesa los datos del formulario para guardar la nueva herramienta
        $controlador->guardar();
        break;

    case 'editar':
        // Muestra el formulario de edición con los datos de una herramienta específica
        $controlador->editar($_GET['codigo']);
        break;

    case 'actualizar':
        // Procesa los datos del formulario de edición y actualiza la herramienta
        $controlador->actualizar();
        break;

    case 'eliminar':
        // Elimina la herramienta correspondiente según el código recibido por GET
        $controlador->eliminar($_GET['codigo']);
        break;

    default:
        // Si no se especifica ninguna acción o la acción es desconocida, se muestra el listado de herramientas
        $controlador->index();
        break;
}
