<?php
// Iniciar la sesión para poder acceder a los datos del usuario logueado
session_start();

// Concatenar el nombre y apellido del usuario autenticado para mostrarlo en pantalla
$nombreCompleto = $_SESSION['usuario']['nombre'] . ' ' . $_SESSION['usuario']['apellido'];
?>

<!-- Incluir la hoja de estilos de Bootstrap desde CDN para usar sus componentes -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Estilos personalizados para mejorar la presentación visual del contenido de bienvenida -->
<style>
    body {
        background-color: #f8f9fa;
        /* Fondo claro */
        color: #343a40;
        /* Texto oscuro */
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .bienvenida-box {
        max-width: 800px;
        /* Ancho máximo del contenedor */
        margin: 50px auto;
        /* Centrado vertical y horizontal */
        background-color: #ffffff;
        /* Fondo blanco */
        padding: 30px;
        /* Espaciado interior */
        border-radius: 10px;
        /* Bordes redondeados */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        /* Sombra suave */
    }

    .bienvenida-box h2 {
        color: #1c1f23;
        /* Color de título principal */
        margin-bottom: 20px;
        font-weight: 600;
    }

    .bienvenida-box h4 {
        color: #495057;
        /* Color de subtítulo */
    }

    .bienvenida-box ul {
        margin-top: 25px;
        /* Espacio antes de la lista */
    }

    .bienvenida-box li {
        padding: 8px 0;
        /* Espacio entre ítems de la lista */
        font-size: 1rem;
        color: #555;
    }
</style>

<!-- Caja principal de bienvenida -->
<div class="bienvenida-box">

    <!-- Título de bienvenida -->
    <h2>Bienvenido al sistema de administración de herramientas</h2>

    <!-- Mostrar nombre completo del administrador de forma segura -->
    <h4>Hola, <?= htmlspecialchars($nombreCompleto) ?></h4>

    <!-- Descripción de funciones disponibles en el panel administrativo -->
    <p class="mt-4">Desde este panel, como <strong>administrador</strong>, puedes realizar las siguientes tareas:</p>

    <!-- Lista de funcionalidades administrativas -->
    <ul class="list-unstyled">
        <li><strong>Gestión de usuarios:</strong> Crear, editar, activar/inactivar o eliminar usuarios del sistema.</li>
        <li><strong>Gestión de herramientas:</strong> Registrar nuevas herramientas, editar su información y controlar su disponibilidad.</li>
        <li><strong>Gestión de préstamos:</strong> Supervisar, registrar y actualizar préstamos de herramientas.</li>
        <li><strong>Consultas:</strong> Visualizar reportes o históricos de préstamos realizados por los usuarios.</li>
    </ul>
</div>