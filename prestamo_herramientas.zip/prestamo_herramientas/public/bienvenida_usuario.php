<?php
// Inicia la sesión para acceder a los datos del usuario autenticado
session_start();

// Guarda el nombre completo del usuario (nombre + apellido) desde la sesión
$nombreCompleto = $_SESSION['usuario']['nombre'] . ' ' . $_SESSION['usuario']['apellido'];
?>
<!-- Vincula la hoja de estilos de Bootstrap desde un CDN para usar sus componentes de interfaz -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Estilos personalizados para el diseño visual de la bienvenida -->
<style>
    body {
        background-color: #f8f9fa;
        /* Color de fondo claro */
        color: #343a40;
        /* Color de texto principal */
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        /* Fuente del sistema */
    }

    .bienvenida-box {
        max-width: 800px;
        /* Ancho máximo del contenedor */
        margin: 50px auto;
        /* Centrado vertical con margen superior */
        background-color: #ffffff;
        /* Fondo blanco */
        padding: 30px;
        /* Espaciado interno */
        border-radius: 10px;
        /* Bordes redondeados */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        /* Sombra para dar profundidad */
    }

    .bienvenida-box h2 {
        color: #1c1f23;
        /* Color del título principal */
        margin-bottom: 20px;
        font-weight: 600;
        /* Grosor de fuente */
    }

    .bienvenida-box h4 {
        color: #495057;
        /* Subtítulo con tono gris oscuro */
    }

    .bienvenida-box ul {
        margin-top: 25px;
        /* Espacio superior antes de la lista */
    }

    .bienvenida-box li {
        padding: 8px 0;
        /* Espaciado vertical entre elementos de lista */
        font-size: 1rem;
        color: #555;
    }
</style>
<!-- Contenedor principal con la información de bienvenida -->
<div class="bienvenida-box">

    <!-- Título principal de la página -->
    <h2>Bienvenido al sistema de préstamos de herramientas</h2>

    <!-- Mensaje personalizado con el nombre del usuario -->
    <h4>Hola, <?= htmlspecialchars($nombreCompleto) ?></h4>

    <!-- Descripción general de las funcionalidades disponibles para el usuario -->
    <p class="mt-4">Desde este panel, como <strong>usuario</strong>, puedes realizar las siguientes acciones:</p>

    <!-- Lista de acciones disponibles para los usuarios registrados -->
    <ul class="list-unstyled">
        <li><strong>Catálogo de herramientas:</strong> Consulta las herramientas disponibles.</li>
        <li><strong>Mis préstamos:</strong> Visualiza tus préstamos actuales y anteriores.</li>
        <li><strong>Solicitar préstamo:</strong> Realiza solicitudes de herramientas según disponibilidad.</li>
        <li><strong>Cambiar contraseña:</strong> Actualiza tu contraseña para mantener la seguridad de tu cuenta.</li>
    </ul>
</div>