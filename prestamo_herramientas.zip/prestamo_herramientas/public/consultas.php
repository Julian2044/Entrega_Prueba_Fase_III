<?php
// Inicia la sesión para acceder a las variables de sesión
session_start();

// Verifica si hay una sesión activa y si el usuario tiene rol de administrador
// Si no cumple la condición, redirige al login para proteger el acceso
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: login.php");
    exit();
}
// Importa el controlador de consultas para poder manejar la lógica del módulo
require_once '../controllers/ConsultaController.php';

// Crea una instancia del controlador para manejar las acciones relacionadas a las consultas
$controlador = new ConsultaController();

// Ejecuta la función principal que carga los datos necesarios y la vista correspondiente
$controlador->index();
