<?php
// Iniciar la sesión para acceder a los datos del usuario
session_start();

// Validar si existe una sesión activa de usuario con rol "usuario"
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'usuario') {
    // Si no cumple con la condición, cerrar sesión y redirigir al login
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Panel de Usuario</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Importación de estilos de Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Estilos generales del layout */
        body,
        html {
            margin: 0;
            height: 100%;
        }

        .dashboard {
            display: flex;
            height: 100vh;
        }

        /* Estilos de la barra lateral */
        .sidebar {
            width: 220px;
            background-color: #1c1f23;
            color: white;
            padding: 1.5rem 1rem;
        }

        .sidebar h5 {
            text-align: center;
            margin-bottom: 0.5rem;
            color: #adb5bd;
        }

        .sidebar .username {
            text-align: center;
            font-size: 0.95rem;
            margin-bottom: 2rem;
            font-weight: 500;
        }

        .sidebar a {
            color: #dee2e6;
            display: block;
            padding: 10px;
            text-decoration: none;
            border-radius: 4px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #343a40;
            color: #fff;
        }

        /* Área de contenido */
        .content-area {
            flex-grow: 1;
            background-color: #f8f9fa;
        }

        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>

<body>

    <div class="dashboard">
        <!-- Barra lateral de navegación del usuario -->
        <nav class="sidebar">
            <h5>Panel del Usuario</h5>

            <!-- Mostrar el nombre completo del usuario desde la sesión -->
            <div class="username">
                <?= htmlspecialchars($_SESSION['usuario']['nombre'] . ' ' . $_SESSION['usuario']['apellido']) ?>
            </div>

            <!-- Menú de opciones para el usuario -->
            <a href="#" onclick="cargarContenido('catalogo_usuario.php', this)">Catalogo de Herramientas</a>
            <a href="#" onclick="cargarContenido('prestamos_usuario.php', this)">Mis Préstamos</a>
            <a href="#" onclick="cargarContenido('registrar_prestamo.php', this)">Solicitar Préstamo</a>
            <a href="#" onclick="cargarContenido('cambiar_password_usuario.php', this)">Cambiar contraseña</a>
            <hr>
            <a href="logout.php" class="text-danger">Cerrar sesión</a>
        </nav>

        <!-- Área donde se carga el contenido dinámico -->
        <div class="content-area">
            <iframe id="contenido" src="bienvenida_usuario.php"></iframe>
        </div>
    </div>

    <!-- Script para manejar la navegación dinámica dentro del panel -->
    <script>
        function cargarContenido(pagina, link) {
            document.getElementById('contenido').src = pagina;
            document.querySelectorAll('.sidebar a').forEach(el => el.classList.remove('active'));
            if (link) link.classList.add('active');
        }
    </script>

</body>

</html>