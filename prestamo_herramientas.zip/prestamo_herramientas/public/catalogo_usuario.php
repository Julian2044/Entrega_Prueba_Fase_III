<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'usuario') {
    header("Location: login.php");
    exit();
}
require_once '../models/Herramienta.php';
$herramientas = Herramienta::obtenerTodos();
include '../views/herramientas/catalogo_usuario.php';