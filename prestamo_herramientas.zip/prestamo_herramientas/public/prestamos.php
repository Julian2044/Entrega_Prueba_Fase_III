<?php
// Inicia la sesión para mantener el control de usuario y mensajes
session_start();

// Se incluye el controlador de préstamos que contiene la lógica para manipular préstamos
require_once '../controllers/PrestamoController.php';

// Se crea una instancia del controlador para ejecutar las acciones
$controlador = new PrestamoController();

// Se captura la acción enviada por la URL, si no se especifica, se usa 'index' como valor por defecto
$accion = $_GET['accion'] ?? 'index';

// Se evalúa la acción mediante una estructura switch
switch ($accion) {
    case 'crear':
        // Muestra el formulario de creación de préstamo (crear.php)
        $controlador->crear();
        break;
    case 'guardar':
        // Procesa el formulario de creación y guarda el nuevo préstamo
        $controlador->guardar();
        break;
    case 'devolver':
        // Marca un préstamo como devuelto utilizando el código proporcionado en la URL
        $controlador->devolver($_GET['codigo']);
        break;
    case 'editar':
        // Carga el formulario de edición del préstamo con los datos existentes
        $controlador->editar($_GET['codigo']);
        break;
    case 'actualizar':
        // Actualiza la fecha estimada de devolución del préstamo
        $controlador->actualizar($_GET['codigo']);
        break;
    default:
        // Muestra la lista de todos los préstamos registrados en el sistema
        $controlador->index();
        break;
}
