<?php
// Inicia la sesión para acceder a la información del usuario logueado
session_start();

// Importa el modelo Usuario para acceder a sus métodos
require_once '../models/Usuario.php';

// Verifica si hay un usuario autenticado; si no, redirige al login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

// Obtiene la información actual del usuario desde la base de datos
$usuario = Usuario::obtenerPorCodigo($_SESSION['usuario']['codigo_usuario']);
// Verifica si el formulario fue enviado mediante el método POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recupera la nueva contraseña enviada por el formulario
    $nuevaPassword = $_POST['nueva_password'] ?? '';

    // Validación: Si la contraseña está vacía, muestra un error
    if (empty($nuevaPassword)) {
        $_SESSION['error'] = "La contraseña no puede estar vacía.";
    } else {
        try {
            // Se encripta la nueva contraseña usando password_hash con algoritmo seguro
            $claveHash = password_hash($nuevaPassword, PASSWORD_DEFAULT);

            // Llama al método actualizar del modelo Usuario para guardar la nueva contraseña
            Usuario::actualizar(
                $usuario['codigo_usuario'], // Se mantiene el mismo código
                $usuario['nombre'],
                $usuario['apellido'],
                $usuario['email'],
                $usuario['rol'],
                $claveHash // Nueva clave encriptada
            );

            // Mensaje de éxito
            $_SESSION['mensaje'] = " Contraseña actualizada correctamente.";
        } catch (Exception $e) {
            // Mensaje de error en caso de excepción
            $_SESSION['error'] = "Error al actualizar: " . $e->getMessage();
        }
    }

    // Refresca los datos del usuario tras la actualización
    $usuario = Usuario::obtenerPorCodigo($_SESSION['usuario']['codigo_usuario']);
}
// Carga la vista correspondiente para mostrar el formulario de cambio de contraseña
include '../views/usuarios/cambiar_password_usuario.php';
