<?php
// Iniciar la sesión
session_start();

// Verificar que el usuario tenga rol de administrador
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    // Si no es admin, redirigir al login
    header("Location: login.php");
    exit();
}

// Incluir el controlador de usuarios
require_once '../controllers/UsuarioController.php';

// Crear una instancia del controlador
$controlador = new UsuarioController();

// Determinar la acción solicitada mediante GET (por ejemplo: usuarios.php?accion=crear)
$accion = $_GET['accion'] ?? 'index';

// Ejecutar la acción correspondiente
switch ($accion) {
    case 'crear':
        // Muestra el formulario de creación de usuario
        $controlador->crear();
        break;

    case 'guardar':
        // Guarda un nuevo usuario en la base de datos
        $controlador->guardar();
        break;

    case 'editar':
        // Carga el formulario para editar un usuario existente
        $controlador->editar($_GET['codigo']);
        break;

    case 'actualizar':
        // Guarda los cambios del usuario editado
        $controlador->actualizar($_GET['codigo']);
        break;

    case 'eliminar':
        // Marca un usuario como inactivo o lo elimina (según implementación)
        $controlador->eliminar($_GET['codigo']);
        break;

    case 'activar':
        // Reactiva un usuario previamente inactivo
        $controlador->activar($_GET['codigo']);
        break;

    default:
        // Muestra la lista de usuarios por defecto
        $controlador->index();
        break;
}
