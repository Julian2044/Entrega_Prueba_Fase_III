<?php
// Se inicia la sesión para acceder a los datos del usuario autenticado
session_start();

// Se incluye el controlador responsable de manejar los préstamos realizados por usuarios
require_once '../controllers/PrestamoUsuarioController.php';

// Verifica si el usuario ha iniciado sesión y si su rol es 'usuario'
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'usuario') {
    // Si no cumple con las condiciones, redirige al login
    header("Location: login.php");
    exit();
}

// Se instancia el controlador que gestiona los préstamos para usuarios
$controlador = new PrestamoUsuarioController();

// Se verifica si la solicitud se hizo mediante el método POST (es decir, si se envió el formulario)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Si es POST, se llama al método para guardar el préstamo
    $controlador->guardar();
} else {
    // Si es GET, se carga el formulario para registrar un nuevo préstamo
    $controlador->crear();
}
