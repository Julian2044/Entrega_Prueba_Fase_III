<?php
// Inicia la sesión para acceder a los datos del usuario logueado
session_start();

// Verifica que el usuario esté autenticado y que su rol sea "usuario"
// Si no cumple, se redirige al formulario de login
if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'usuario') {
    header("Location: login.php");
    exit();
}

// Se importa el controlador correspondiente para manejar préstamos de usuarios
require_once '../controllers/PrestamoUsuarioController.php';

// Se instancia el controlador para ejecutar la acción solicitada
$controlador = new PrestamoUsuarioController();

// Se obtiene la acción a ejecutar desde la URL, o se define 'index' como predeterminada
$accion = $_GET['accion'] ?? 'index';

// Se usa un switch para determinar qué método del controlador ejecutar
switch ($accion) {
    case 'crear':
        // Muestra el formulario para crear un nuevo préstamo (usuario_crear.php)
        $controlador->crear();
        break;
    case 'guardar':
        // Procesa y guarda la solicitud de préstamo enviada por el usuario
        $controlador->guardar();
        break;
    default:
        // Muestra la lista de préstamos del usuario (usuario_index.php)
        $controlador->index();
        break;
}
