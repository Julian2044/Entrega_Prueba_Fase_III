<?php
session_start();
require_once '../config/conexion.php';

if (isset($_SESSION['usuario']) && is_array($_SESSION['usuario'])) {
    $rol = $_SESSION['usuario']['rol'] ?? '';

    if ($rol === 'admin') {
        header("Location: admin.php");
        exit;
    } elseif ($rol === 'usuario') {
        header("Location: usuario.php");
        exit;
    } else {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($password, $usuario['password'])) {
        $_SESSION['usuario'] = $usuario;
        $rol = $usuario['rol'] ?? '';

        if ($rol === 'admin') {
            header("Location: admin.php");
        } elseif ($rol === 'usuario') {
            header("Location: usuario.php");
        } else {
            $_SESSION['error'] = "Rol no válido.";
            header("Location: login.php");
        }
        exit;
    } else {
        $_SESSION['error'] = "Correo o contraseña incorrectos.";
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar sesión</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #1c1f23;
            color: #dee2e6;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            background-color: #343a40;
            padding: 2.5rem 2rem;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.25);
            width: 100%;
            max-width: 400px;
        }

        .login-box h4 {
            text-align: center;
            margin-bottom: 1.5rem;
            color: #ffffff;
        }

        .form-label {
            color: #dee2e6;
            font-weight: 500;
        }

        .form-control {
            background-color: #495057;
            border: none;
            color: #dee2e6;
        }

        .form-control:focus {
            background-color: #495057;
            color: #fff;
            border-color: #dc3545;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25);
        }

        .btn-danger-custom {
            background-color: #dc3545;
            border: none;
        }

        .btn-danger-custom:hover {
            background-color: #bb2d3b;
        }

        .footer-note {
            text-align: center;
            margin-top: 1rem;
            font-size: 0.85rem;
            color: #adb5bd;
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h4>Iniciar Sesión</h4>

        <?php if (!empty($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?= $_SESSION['error'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">Correo electrónico</label>
                <input type="email" name="email" class="form-control" id="email" required autofocus>
            </div>

            <div class="mb-4">
                <label for="password" class="form-label">Contraseña</label>
                <input type="password" name="password" class="form-control" id="password" required>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-danger-custom">Ingresar</button>
            </div>
        </form>

        <div class="footer-note mt-4">
            Sistema de Gestión de Préstamos<br>
            &copy; <?= date("Y") ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>