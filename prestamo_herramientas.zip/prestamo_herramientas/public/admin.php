<!-- Estructura HTML del panel de administración -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS desde CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Estilos internos personalizados -->
    <style>
        body, html {
            margin: 0;
            height: 100%;
            overflow: hidden;
        }

        .dashboard {
            display: flex;
            height: 100vh;
            width: 100vw;
        }

        .sidebar {
            width: 220px;
            background-color: #1c1f23;
            color: white;
            padding: 1.5rem 1rem;
        }

        .sidebar h5 {
            text-align: center;
            font-size: 1.1rem;
            color: #adb5bd;
            margin-bottom: 0.5rem;
        }

        .sidebar .username {
            text-align: center;
            font-size: 0.95rem;
            font-weight: 500;
            margin-bottom: 2rem;
            color: #ffffff;
        }

        .sidebar a {
            color: #dee2e6;
            display: block;
            padding: 10px;
            text-decoration: none;
            border-radius: 4px;
            transition: background 0.2s;
            font-size: 0.95rem;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background-color: #343a40;
            color: #ffffff;
        }

        .content-area {
            flex-grow: 1;
            background-color: #f4f6f9;
        }

        iframe {
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Menú lateral izquierdo -->
        <nav class="sidebar">
            <h5>Panel Administrativo</h5>

            <!-- Mostrar nombre completo del administrador -->
            <div class="username">
                <?= htmlspecialchars($_SESSION['usuario']['nombre'] . ' ' . $_SESSION['usuario']['apellido']) ?>
            </div>

            <!-- Enlaces a módulos del panel de administración -->
            <a href="#" onclick="cargarContenido('usuarios.php', this)">Gestión de Usuarios</a>
            <a href="#" onclick="cargarContenido('herramientas.php', this)">Gestión de Herramientas</a>
            <a href="#" onclick="cargarContenido('prestamos.php', this)">Gestión de Préstamos</a>
            <a href="#" onclick="cargarContenido('consultas.php', this)">Consulta de Préstamos</a>
            <hr class="text-secondary">
            <a href="logout.php" class="text-danger">Cerrar Sesión</a>
        </nav>

        <!-- Área de contenido cargado mediante iframe -->
        <div class="content-area">
            <!-- Página por defecto al ingresar al panel -->
            <iframe id="contenido" src="bienvenida_admin.php"></iframe>
        </div>
    </div>

    <!-- Script para cargar contenido dentro del iframe y activar el link correspondiente -->
    <script>
        function cargarContenido(pagina, link) {
            document.getElementById('contenido').src = pagina;
            document.querySelectorAll('.sidebar a').forEach(el => el.classList.remove('active'));
            if (link) link.classList.add('active');
        }
    </script>

    <!-- Bootstrap JS desde CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>